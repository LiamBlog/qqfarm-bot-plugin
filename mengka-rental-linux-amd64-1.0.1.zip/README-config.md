# 萌卡 NT 租用中心 — 配置示例

## 独立接入模式（直连萌卡节点 WebSocket）

```bash
# 基本启动
./mengka-rental \
  -upstream "ws://your-mengka-node:port/ws/plugin" \
  -token "你的节点接入令牌" \
  -data ./data \
  -addr ":18080"

# 令牌也可通过环境变量传递（避免出现在进程列表）
MENGKA_NODE_TOKEN=你的节点接入令牌 ./mengka-rental -upstream "ws://..."
```

- `MENGKA_NODE_TOKEN`：节点令牌，仅保存在服务端，绝不下发浏览器。
- `MENGKA_PLUGIN_CONNECTION_FILE`：由萌卡宿主框架注入；存在时自动切换为原生托管模式，忽略 `-upstream`。

## 原生托管插件模式（随萌卡 NT 启动）

将对应平台压缩包内 `mengka-plugin.json` 与二进制放在同一插件目录，
由萌卡 NT 3.0.7+ 加载。插件进程的标准输出只承载 NDJSON 协议帧，日志走标准错误。

## 数据与账本

- SQLite 数据库写入 `-data` 目录（原生模式下由宿主连接文件 `data_directory` 指定）。
- 首个注册用户自动成为管理员。
- 管理员可在 Web 界面创建套餐、生成卡密、调整金币、停用/启用租用。

## 租用接入 API（客户端用）

```
POST /rapi/{租用令牌}/action   {"action":"send_group_message","params":{...}}
GET  /rapi/{租用令牌}/events   轮询绑定账号事件
```

- 动作必须在该租用的白名单内（默认：get_login_info、get_self_info、
  send_group_message、send_friend_message、get_group_list、get_friend_list）。
- `params.self_id` 一律被网关改写为租用绑定的账号，无法伪造他人账号。
- 未绑定账号的全局事件不会下发给任何租户。
